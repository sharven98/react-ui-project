
const Info = [
    {
        tagline: "Craving for something spicy ?",
        para: "Order from the best burger master near you.",
        city: "Panjim, Tonca, Mapusa",
    },
    
]
 
export default Info;
